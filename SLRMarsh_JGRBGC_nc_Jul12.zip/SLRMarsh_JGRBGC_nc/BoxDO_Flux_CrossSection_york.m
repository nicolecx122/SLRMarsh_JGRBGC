clear
close all
clc

path='/Users/ncai/OneDrive/Projects/york_marsh/results/';
path_store='/Users/ncai/OneDrive/Projects/york_marsh/results/WQ_york/';

run_base='tun44h';
slr={'slr1_5m_macc'}; %{'SLR0_5m','SLR1m'};
slrn={'SLR = 1.5 m'}; %{'SLR=0.5m','SLR=1m'};

isave=0;
fsize=[1,1,1500,450];
nfontsize=18;

%cross-section box
csids=[8 7 2 1]; %box chosen between csid and csid+1 in fluxflag.prop
filename=[path,run_base,'/fluxflag.prop'];
fluxflag=load(filename);
tract={'Gloucester Point','Clay Bank','West Point','Eltham','Lee','Hill','Sweet Hall','Cousaic','Cohoke','Broad Creek','Horseshoe',};


%period
time_ref=datenum([2010,1,1]); %when of the output start, refer to stack(1) of readout
year={'2010'};%}; %years for
monofy={'6','8'}; %mon picked for each year
monofy_n=[str2num(monofy{1}),str2num(monofy{end})];
dayofm={'1','31'}; %start day and end day of the picked months

nd=30;int=30;
time_flux=0:(150/86400):(365*length(year)); time_flux=time_flux';

%%
%---------------------------------------------------------------------------------
%read in *z files 
%---------------------------------------------------------------------------------
para_trans={'basalDOO','HRDOO','chemDOO','NitDOO','reaDOO','phoDOO','SED_BENDO','veggrDOO'};
para_name={'Phytoplankton respiration','Heterotrophic respiration','Sulfide oxidation','Nitrification','Reaeration','Phytoplankton production','Net metabolism of the benthic layer','Vegetation production'};

%load database of mean in selected period in all the elems      
filename=['york_SLR_DO_box','_',monofy{1},'_',monofy{2},'_year_',num2str(length(year)),'_slr_',num2str(length(slr))];
if exist([path,run_base,'/',filename,'.mat'],'file')
    load([path,run_base,'/',filename,'.mat'])
else

    %---------base run---------
    for r1=1:length(para_trans)
        load([path,run_base,'/',run_base,'_',para_trans{r1},'_Zlayer_int_1.mat']);
        load([path,run_base,'/',run_base,'_',para_trans{r1},'_Zlayer_int_2.mat']);
        load([path,run_base,'/',run_base,'_',para_trans{r1},'_Zlayer_int_3.mat']);
        load([path,run_base,'/',run_base,'_',para_trans{r1},'_Zlayer_int_4.mat']);
        load([path,run_base,'/',run_base,'_',para_trans{r1},'_Zlayer_int_5.mat']);
        var=[var1; var2; var3; var4; var5]; %temp modify
        clear var1 var2 var3 var4 var5
        var(var<-99)=nan;
        time=var(:,1)+time_ref;
        var=var(:,2:end); 

        var2=[];
        for r2=1:length(year)         
            %renew period        
            time_left=datenum([year{r2},',',monofy{1},',',dayofm{1}]);
            time_right=datenum([year{r2},',',monofy{2},',',dayofm{2}]);

            tid=find((time<time_right).*(time>time_left)); %pick certain period
            var1=var(tid,:);
            var2=[var2;var1]; %combine all the picked portions
        end %r2:: year

        vbas(r1,:)=mean(var2,1,'omitnan')/1000; %unit: kg/m^2/day, averaged over time; (length(para_trans),nf)
        clear var*
    end %r1:: para_trans

   %---------slr run---------
    for r2=1:length(slr)
        run=[run_base,'_',slr{r2}];
        for r1=1:length(para_trans)

            load([path,run,'/',run,'_',para_trans{r1},'_Zlayer_int_1.mat']);
            load([path,run,'/',run,'_',para_trans{r1},'_Zlayer_int_2.mat']);
            load([path,run,'/',run,'_',para_trans{r1},'_Zlayer_int_3.mat']);
            load([path,run,'/',run,'_',para_trans{r1},'_Zlayer_int_4.mat']);
            load([path,run,'/',run,'_',para_trans{r1},'_Zlayer_int_5.mat']);
            var=[var1; var2; var3; var4; var5]; %temp modify
            clear var1 var2 var3 var4 var5
            var(var<-99)=nan;
            time=var(:,1)+time_ref; 
            var=var(:,2:end); 

            var2=[];
            for r3=1:length(year)         
                %renew period        
                time_left=datenum([year{r3},',',monofy{1},',',dayofm{1}]);
                time_right=datenum([year{r3},',',monofy{2},',',dayofm{2}]);

                tid=find((time<time_right).*(time>time_left)); %pick certain period
                var1=var(tid,:);
                var2=[var2;var1]; %combine all the picked portions
            end %r3:: year

            vslr(r1,:,r2)=mean(var2,1,'omitnan')/1000; %unit: kg/m^2/day, averaged over time; (length(para_trans),nf,length(slr))
            clear var*            
        end %%mm :: para

    end %r2::slr

    save([path,run_base,'/',filename,'.mat'],'vbas','vslr')    
end %exit
%back up
vbas0=vbas;
vslr0=vslr;
    
figure('Position',fsize);    
%loop of each box    
for csid=csids
    %picked elemements in each section
    fxid=find(fluxflag(:,2)==csid); %fxid of elem for future use in area intergration
    nf=length(fxid); %# of elem for calculation
    vbas=vbas0(:,fxid); %para for selected elem
    vslr=vslr0(:,fxid); %para for selected elem
    
    %---------------------------------------------------------------------------------
    %read in *gr3 for area calc
    %---------------------------------------------------------------------------------
    if exist('/Users/ncai/Documents/york_marsh/Grid_v24/hgrid_area_york.mat','file')
            load('/Users/ncai/Documents/york_marsh/Grid_v24/hgrid_area_york.mat')
            farea(:,1)=squeeze(area_elem(fxid));
    else
        fname='/Users/ncai/Documents/york_marsh/Grid_v24/hgrid.bath1_full';
        fid=fopen(fname,'r');
        char=fgetl(fid);
        tmp1=str2num(fgetl(fid));
        fclose(fid);
        ne=fix(tmp1(1));
        np=fix(tmp1(2));
        fid=fopen(fname);
        c3=textscan(fid,'%d%f%f%f',np,'headerLines',2);
        fclose(fid);
        xx=c3{2}(:);
        yy=c3{3}(:);    
        fid=fopen(fname);
        c2=textscan(fid,'%d%d%d%d%d%d',ne,'headerLines',2+np);
        fclose(fid);
        i34=c2{2}(:);
        nm(1:ne,1:4)=nan;
        for i=1:ne
          for j=1:i34(i)
            nm(i,j)=fix(c2{j+2}(i));
          end %for j
        end %for i   

        %---------area for target elem, spatially intergrated---------
        for r1=1:nf    
            farea(r1,1)=N_areacalc(xx(nm(fxid(r1),1:i34(fxid(r1)))),yy(nm(fxid(r1),1:i34(fxid(r1))))); 
        end %for i 
    end %exist    

    vbas(isnan(vbas))=0;
    vslr(isnan(vslr))=0;

    tbas=vbas*farea; %unit: kg/day
    for r2=1:length(slr)
        tslr(:,r2)=vslr(:,:,r2)*farea; %unit: kg/day
    end
    clear farea

    %%
    %---------------------------------------------------------------------------------
    %calculate flux (advection)
    %---------------------------------------------------------------------------------

    xxfilename=['york_SLR_DO_flux',num2str(csid),'_',monofy{1},'_',monofy{2},'_year_',num2str(length(year)),'_slr_',num2str(length(slr))];
    if exist([path,run_base,'/',xxfilename,'.mat'],'file')
        load([path,run_base,'/',xxfilename,'.mat'])
    else
        %---------base run---------
        filename=[run_base,'_Oflux.mat'];
        load([path,run_base,'/',filename])
        oflux_pbas=squeeze(Oflux(:,3,csid));
        oflux_nbas=squeeze(Oflux(:,4,csid));
        clear Oflux


        [time_m, oflux_pbasm]=Q_ave(time_flux,oflux_pbas,nd,int);
        [time_m, oflux_nbasm]=Q_ave(time_flux,oflux_nbas,nd,int);
        oflux_basm=oflux_pbasm+oflux_nbasm;        
        tmp=reshape(oflux_pbasm,12,[]);
        oflux_pbasr=mean(tmp,2);
        tmp=reshape(oflux_nbasm,12,[]);
        oflux_nbasr=mean(tmp,2);
        oflux_basr=oflux_pbasr+oflux_nbasr;    

        pid=monofy_n(1):monofy_n(end);
        oflux_pbasf=86400*mean(oflux_pbasr(pid))/1000; %unit: kg/day
        oflux_nbasf=86400*mean(oflux_nbasr(pid))/1000;
        oflux_basf=86400*mean(oflux_basr(pid))/1000;

        obas=[-oflux_pbasf;-oflux_nbasf;-oflux_basf];

        %---------slr run---------
        for r2=1:length(slr)
            run=[run_base,'_',slr{r2}];

            filename=[run,'_Oflux.mat'];
            load([path,run,'/',filename])
            oflux_pslr(:,r2)=squeeze(Oflux(:,3,csid));
            oflux_nslr(:,r2)=squeeze(Oflux(:,4,csid));
            clear Oflux


            [time_m, oflux_pslrm(:,r2)]=Q_ave(time_flux,oflux_pslr(:,r2),nd,int);
            [time_m, oflux_nslrm(:,r2)]=Q_ave(time_flux,oflux_nslr(:,r2),nd,int);
            oflux_slrm(:,r2)=oflux_pslrm(:,r2)+oflux_nslrm(:,r2);        
            tmp=reshape(oflux_pslrm(:,r2),12,[]);
            oflux_pslrr(:,r2)=mean(tmp,2);
            tmp=reshape(oflux_nslrm(:,r2),12,[]);
            oflux_nslrr(:,r2)=mean(tmp,2);
            oflux_slrr(:,r2)=oflux_pslrr(:,r2)+oflux_nslrr(:,r2);    

            oflux_pslrf(r2)=86400*mean(oflux_pslrr(pid,r2),1)/1000; %unit: kg/day
            oflux_nslrf(r2)=86400*mean(oflux_nslrr(pid,r2),1)/1000;
            oflux_slrf(r2)=86400*mean(oflux_slrr(pid,r2),1)/1000;
            oslr(:,r2)=[-oflux_pslrf;-oflux_nslrf;-oflux_slrf];

        end %r2:: slr

        save([path,run_base,'/',xxfilename,'.mat'],'obas','oslr')    
    end %exit

    %%

    %bar plot
    ssid=find(csids==csid);
    subplot(1,length(csids),ssid)

    %kinetic + net advection
    sid=[8 6 7 1 5 4]; sid=flip(sid); aid=3;
    tmp1=tbas(sid);tmp1(aid)=tmp1(aid)+tbas(2)+tbas(3);
    tmp2=tslr(sid);tmp2(aid)=tmp2(aid)+tslr(2,1)+tslr(3,1);
    tmp_term=para_name(sid);tmp_term{aid}='Water column respirations';
    barvar(:,1)=[tmp1;obas(3)];
    barvar(:,2)=[tmp2;oslr(3,1)];
    barterm=[tmp_term,'Net outflux'];
    sumvar=sum(barvar);
    barvar_s=[barvar;sumvar];
    barterm_s=[barterm,'Total change'];
    diffvar(:,1)=barvar_s(:,2)-barvar_s(:,1);
    diffvar(:,2)=100*diffvar(:,1)./abs(barvar_s(:,1));

    %plot
    x=1:length(barterm_s); x(end)=x(end)+0.5;
    a=barh(x,barvar_s/1000,'FaceColor','flat');
    
    if ssid==1
        set(gca,'YTick',x,'YTickLabel',barterm_s,'FontSize',18)
        set(gca,'YTickLabelRotation',45)
    else
        set(gca,'YTick',[])
    end    
    
    %legend
    if ssid==1
    % formatSpec = '%.2e';
    % leg_str={['Base, ',num2str(sumvar(1),formatSpec), ' kg day^-^1'],['SLR=1m, ',num2str(sumvar(2),formatSpec), ' kg day^-^1']};
    leg_str={['Base'],['SLR = 1.5 m']};
    legend(leg_str,'Location','southeast')
    end 
% 	ylim([x(1)-0.5,x(end)+0.5])
    
    xlabel('T day^-^1','FontSize',18);
    if csid<=2
        xlim([-200 200])
        set(gca,'XTick',-200:200:200,'FontSize',18)
    else
        xlim([-62 62])
        set(gca,'XTick',-60:60:60,'FontSize',18)
    end
    
%     set(gca,'fontsize',nfontsize);
    title([tract{csid+1},' to ',tract{csid}],'FontSize',18)
     

    title([tract{csid+1},' to ',tract{csid}],'FontSize',18)
    
    for r1=1:length(x)
        if ~isnan(diffvar(r1,2))
%             if barvar_s(r1,2)>0
%                 text(max(barvar_s(r1,:)),x(r1),num2str(diffvar(r1,2),'%.1f%%'),...
%                     'HorizontalAlignment','left',...
%                     'VerticalAlignment','middle',...
%                     'FontSize',12)        
%             else
%                 text(min(barvar_s(r1,:)),x(r1),num2str(-diffvar(r1,2),'%.1f%%'),...
%                     'HorizontalAlignment','right',...
%                     'VerticalAlignment','middle',...
%                     'FontSize',12)    
%             end
            if barvar_s(r1,2)>0
                text(0,x(r1),num2str(diffvar(r1,2),'%.1f%%'),...
                    'HorizontalAlignment','right',...
                    'VerticalAlignment','middle',...
                    'FontSize',16)        
            else
                text(0,x(r1),num2str(-diffvar(r1,2),'%.1f%%'),...
                    'HorizontalAlignment','left',...
                    'VerticalAlignment','middle',...
                    'FontSize',16)    
            end
        end %isnan
    end



end %csids

%%
if isave==1
    vid=1;
    out_name=[run_base,'_slr_DO_box_',monofy{1},'_',monofy{2},'_year_',num2str(length(year)),'_v',num2str(vid)];
    saveas(gcf,[path,run_base,'/',out_name,'.fig'])
    print('-dpng',[path_store,out_name,'.png'],'-r800')
end










