clear
close all
clc

path_org='/Users/ncai/OneDrive/Projects/york_marsh/results/';
path_store='/Users/ncai/OneDrive/Projects/york_marsh/results/WQ_york/';
path_mat='/Users/ncai/OneDrive/VIMS/Dissertation/Chap3_4/open_database/SLRMarsh_JGRBGC/';

isave=0; %flag to save the figure, png
run_base='tun44h';
pver=1; %version id
imk={'a','b','c','d','e','f','g','h','i','j'};
isave_mat=1;

imode=1; %1: base vs. slr 1.5m; 2: base vs. no marsh
iszoom=1; %1: zoom in to T0
if imode==1
    run={run_base,[run_base,'_slr1_5m_macc']}; 
    leg_str={'Base','SLR = 1.5 m'};
    outname=[run_base,'_slr_DO'];
elseif imode==2
    run={run_base,[run_base,'_0']}; 
    leg_str={'Base','NV0'};
    outname=[run_base,'_nomarsh_DO'];
end %imode
if iszoom==1
    outname=[outname,'_zoom'];
end
outname=[outname,'_v',num2str(pver)];

%pick output stations
sta_ht=[37 35 ];%33];
sta_name={'Sweet Hall Creek 1','Sweet Hall Creek 2'};%,'Sweet Hall bed'};
var_pkprt={'Water depth (m)','DO (g O_2 m^-^3)','PO_4^3^+ (g P m^-^3)','PO_4^3^+ flux (g P m^-^2 day^-^1)','Denitrification (g N m^-^3 day^-^1)'};
time_ref=datenum([2010,1,1]);

%parameters for figure
iylable=0; %1: print legend
isleg=0;
fsize=[1,1,400*length(sta_ht),750];
nfontsize=19;
T0=163:2:171; T0=T0'; 
YT=[0 365];
mon_str={'Jan','Mar','May','Jul','Sep','Nov'};

var_name={'Sal','Temp','PB1','GP1','BMP1','WSPB1',...
    'PB10','PB2','GP2','BMP2','WSPB2','PB20',...
    'PB3','GP3','BMP3','WSPB3','PB30',...
    'RPOC','rKRPOC','WSRP','FCRP1','FCRP2','FCRP3','RPOC0','nRPOC', ...
    'LPOC','rKLPOC','WSLP','FCLP1','FCLP2','FCLP3','RPOC0','nLPOC',...
    'DOC','xKHR','xDenit','rKDOC','rKHORDO','rKDC','rKTDOM','FCDP1','FCDP2','FCDP3','rKHR1','rKHR2','rKHR3','nDOC',...
    'RPON','rKRPON','FNRP','FNR1','ANC1','FNR2','ANC2','FNR3','ANC3','RPON0','nRPON',...
    'LPON','rKLPON','FNLP','FNL1','FNL2','FNL3','LPON0','nLPON',...
    'DON','rKDON','FNDP','FND1','FND2','FND3','nDON,',...
    'NH4','xNit','rNitM','rKhNitN','rKhNitDO','FNIP','FNI1','FNI2','FNI3','PrefN1','PrefN2','PrefN3','nNH4',...
    'NO3','ANDC','xDenit','nNO3',...
    'RPOP','rKRPOP','FPRP','FPR1','APC1','FPR2','APC2','FPR3','APC3','RPOP0','nRPOP',...
    'LPOP','rKLPOP','FNLP','FPL1','FPL2','FPL3','LPOP0','nLPOP',...
    'DOP','rKDOP','FPDP','FPD1','FPD2','FPD3','nDOP',...
    'PO4t','rKPO4p','TSED','WSSED','FPIP','FPI1','FPI2','FPI3','nPO4t',...
    'SU','rKSUA','rKSU','rKTSUA','WSPB1','FSPP','ASCd','FSPd','SU0','nSU',...
    'SAt','rKSAp','FSIP','FSId','SAt0','nSAt',...
    'COD','rKCOD','rKHCOD','rKCD','rKTCOD','nCOD',...
    'DOO','DOsat','rKr','AOC','AON','nDO'};
para_tar={'DOO','PO4t','nPO4t','xDenit'};
npara=length(para_tar);
%para_name={'Dissolved oxygen (g m^-^3)','Dissolved organic carbon (g m^-^3)'};
for r1=1:npara
    rtmp=find(strcmp(var_name,para_tar(r1)));
    varpk(r1)=rtmp(1);
end %r1::npara

%load model results
for pp=1:length(run)
    path=[path_org,run{pp},'/'];

    %model results
    % load([path_org,'Station_info\Station_info.mat']);
    load([path,run{pp},'_cstation.mat']); 
    
    para_all(:,:,:,pp)=para;
    clear para
end %pp::run

elev=load([path_org,run_base,'_hydro/1_20_elev.york.marsh.out']); 
%elev=load([path_org,run_base,'/1_4_elev.york.marsh.out']); 
T_elev=elev(:,1);
elev=elev(:,2:end);
bathy=load([path_org,run_base,'/depth.york.marsh.out']); 
bathy=bathy(:,2); bathy=bathy';
depth=elev+bathy;
depth=max(0,depth);

if imode==1
    elev_slr=load([path_org,run_base,'_slr1_5m_macc_hydro/1_20_elev.york.marsh.out']); 
    % T_elev=elev_slr(:,1);
    elev_slr=elev_slr(:,2:end);
    bathy_slr=load([path_org,run_base,'_slr1_5m_macc/depth.york.marsh.out']); 
    bathy_slr=bathy_slr(:,2); bathy_slr=bathy_slr';
    depth_slr=elev_slr+bathy_slr;
    depth_slr=max(0,depth_slr);
end %imode


figure('Position',fsize);

if iszoom==0
    nvar=length(varpk);
else
    nvar=(length(varpk)+1);
end %iszoom

for r1=1:nvar
    if iszoom==0
        mr1=r1+1;
    else
        mr1=r1;
    end

    for r2=1:length(sta_ht)
        pid=(length(sta_ht)+0)*(mr1-1)+r2;
        if mr1==1 %elev or depth
        
            if imode==1
                subplot((length(varpk)+1),(length(sta_ht)),pid)  
                tvar=squeeze(depth(:,sta_ht(r2)));        
                plot(T_elev,tvar,'LineWidth',1.5); hold on                    
                tvar=squeeze(depth_slr(:,sta_ht(r2)));    
                plot(T_elev,tvar,'LineWidth',1.5)                          
            else %marsh removel, no change of elev            
                subplot((length(varpk)+1),(length(sta_ht)),pid)  
                tvar=squeeze(depth(:,sta_ht(r2)));        
                plot(T_elev,tvar,'LineWidth',1.5)
            end %imode

        else
            subplot((length(varpk)+1),(length(sta_ht)),pid)  
            tvar=squeeze(para_all(:,sta_ht(r2),varpk(mr1-1),:));        
            if strcmp(para_tar{mr1-1},'xDenit') 
                ANDC=0.933;
                DOCid=find(strcmp(var_name,'DOC'));
                DOC=squeeze(para_all(:,sta_ht(r2),DOCid(1),:));     
                tvar=ANDC*tvar.*DOC;
            end
            plot(T,tvar,'LineWidth',1.5)           
          
        end% elev/depth or cstation values
        
        hold on

        if iszoom==1
            xlim([T0(1) T0(end)])
        else
            xlim(YT)
            %add box to zoom-in
            y=[0 100]; x=[T0 T0];
            plot(x,y,':','LineWidth',0.75,'Color',[0.25 0.25 0.25])         
        end %xlim

        if mr1==length(varpk)+1 
            if iszoom==1
                time=time_ref+T0;
                T0_str=datestr(T0,'mm/dd');
                set(gca,'XTick',T0,'XTickLabel',T0_str,'FontSize',nfontsize)
            else
                set(gca,'XTick',0:60.83:365,'XTickLabel',mon_str,'FontSize',nfontsize) 
            end
        else
            set(gca,'XTick',[],'XTickLabel',[],'FontSize',20)
        end %bottom panels
        
%         if mr1==1
%             title(sta_name(r2))
%         end%station
% 
%         if r2==1
%             ylabel(var_pkprt{mr1})
%         end %variable

%         if mr1==4&&r2==2
%             legend(leg_str,'Location','northwest')
%         end %legend
        
        if iszoom==1
            if mr1>1
                if strcmp(para_tar{mr1-1},'DOO') 
                    ylim([0 10])
                    set(gca,'YTick',0:5:20)
                    %add box to zoom-in
                    y=[2 2]; x=[T(1) T(end)];
                    plot(x,y,':','LineWidth',0.75,'Color',[0.25 0.25 0.25])                
                end            
                if strcmp(para_tar{mr1-1},'PO4t')  
                    ylim([0 0.2])
                    set(gca,'YTick',0:0.1:0.3)
                end
                if strcmp(para_tar{mr1-1},'nPO4t') 
                    ylim([-0.01 0.1])
                end                    
                if strcmp(para_tar{mr1-1},'NO3') 
                    ylim([0 0.005])
                end                
                if strcmp(para_tar{mr1-1},'NH4') 
                    ylim([0 0.15])
                    set(gca,'YTick',0:0.05:0.15)
                end                         
                if strcmp(para_tar{mr1-1},'xDenit') 
                    if sta_ht(r2)==35
                        ylim([0 0.002])
                        set(gca,'YTick',0:0.001:0.012)
                    else
                        ylim([0 0.008])
                        set(gca,'YTick',0:0.004:0.012)
                    end                    
                end                                 
            else %elev/depth
                if sta_ht(r2)==37
                    ylim([0 0.7])
                    set(gca,'YTick',0:0.35:15)    
                elseif sta_ht(r2)==33
                    ylim([0.5 2.5])
                    set(gca,'YTick',0.5:1:5)          
                elseif sta_ht(r2)==35
                    ylim([0 4])
                    set(gca,'YTick',0:2:5)                    
                end
            end %mr1>1

        else %iszoom==0
            if strcmp(para_tar{mr1-1},'DOO') 
                ylim([0 20])
                set(gca,'YTick',0:10:20)
                %add box to zoom-in
                y=[2 2]; x=[T(1) T(end)];
                plot(x,y,':','LineWidth',0.75,'Color',[0.25 0.25 0.25])                
            end            
            if strcmp(para_tar{mr1-1},'PO4t')  
                ylim([0 0.5])
                set(gca,'YTick',0:0.25:100)
            end
            if strcmp(para_tar{mr1-1},'nPO4t') 
                if sta_ht(r2)==35
                    ylim([-0.005 0.01])
                else
                    ylim([-0.05 0.1])
                end
            end                    
            if strcmp(para_tar{mr1-1},'NO3') 
                ylim([0 0.005])
            end                
            if strcmp(para_tar{mr1-1},'NH4') 
                ylim([0 0.15])
                set(gca,'YTick',0:0.05:0.15)
            end                         
            if strcmp(para_tar{mr1-1},'xDenit') 
                if sta_ht(r2)==35
                    ylim([0 0.008])
                else
                    ylim([0 0.2])
                    set(gca,'YTick',0:0.1:100)
                end
            end                                 

        end %iszoom

        set(gca,'fontsize',nfontsize);      
       
    end %r2::stations
end %mr1::variable

%save edit
if isave==1
    set(gcf,'PaperPositionMode','auto') 
    print('-dpng',[path_store,outname,'.png'],'-r300')       
end  

para_slr=squeeze(para_all(:,sta_ht,varpk,:));
if isave_mat==1
    save([path_mat,'WQ_highfreq_slr.mat'],'para_slr','depth','depth_slr')
end







