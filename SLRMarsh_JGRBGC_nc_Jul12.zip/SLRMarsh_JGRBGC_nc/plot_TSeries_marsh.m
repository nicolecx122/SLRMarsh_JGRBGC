clear
close all
clc

run={'tun44h','wun44h','xun44h','yun44h'}; 

run_base='tun44h';

path_org='/Users/ncai/Documents/york_marsh/results/';
path_store='/Users/ncai/Documents/york_marsh/results/WQ_york/';
pver=1;
fname=[run_base,'_SHmarsh_',num2str(pver)];
varname={'marsh_ab','marsh_bl','ICM_PrmPrdtveg'};


%flag to save the figure, png
isave=0;


isbio=1; %0: seperate abveg and blveg; 1: combine abveg and blveg; 
imode=2; %1: york; 2: SH

%to modify time
time_ref=datenum([2010,1,1]);
time_left=datenum([2010,1,1]);
time_right=datenum([2014,1,1]);  

%outputs
outname=[run_base,'_marsh_biomass_pp'];
if isbio==1
    outname=[outname,'_uni'];
end
if imode==1
    outname=[outname,'_york'];
elseif imode==2
    outname=[outname,'_SH'];
end
pver=2;
imk={'a','b','c','d','e','f','g','h','i','j'};

%plot setup
if isbio==0
    fsize=[1,1,600,600];
elseif isbio==1
    fsize=[1,1,600,400];
end %isbio
nfontsize=19;


%------------read in mapping, calc elem area------------
%pick marsh in SH
if imode==1
    york=load('/Users/ncai/Documents/york_marsh/Grid_v24/BPfiles/york.prop');
    sid=find(york(:,2)==1);
else    
    SH=load('/Users/ncai/Documents/york_marsh/Grid_v24/BPfiles/sweethall.prop');
    sid=find(SH(:,2)==1);
end

%read in hgrid.gr3 for elem area
if imode==1
    if exist('/Users/ncai/Documents/york_marsh/Grid_v24/hgrid_area_york.mat','file')
        load('/Users/ncai/Documents/york_marsh/Grid_v24/hgrid_area_york.mat')
        tar_area=york_area;
    else

        gridname='/Users/ncai/Documents/york_marsh/Grid_v24/hgrid.bath1_full';
        %read *gr3 or *ll
        fid=fopen(gridname,'r');
        char=fgetl(fid);
        tmp1=str2num(fgetl(fid));
        fclose(fid);

        ne=fix(tmp1(1));
        np=fix(tmp1(2));

        fid=fopen(gridname);
        c1=textscan(fid,'%d%f%f%f',np,'headerLines',2);
        fclose(fid);
        fid=fopen(gridname);
        c2=textscan(fid,'%d%d%d%d%d%d',ne,'headerLines',2+np);
        fclose(fid);

        x=c1{2}(:);
        y=c1{3}(:);
        Cd=c1{4}(:); Cd=Cd';%for TidalEnergy calc
        i34=c2{2}(:);

        nm(1:ne,1:4)=nan;
        for i=1:ne
          for j=1:i34(i)
            nm(i,j)=fix(c2{j+2}(i));
          end %for j
          %calc elem area
          area_elem(i)=N_areacalc(x(nm(i,1:i34(i))),y(nm(i,1:i34(i))));
        end %for i
        york_area=area_elem(sid);
        tar_area=area_elem(sid);

        save('/Users/ncai/Documents/york_marsh/Grid_v24/hgrid_area_york.mat','ne','np','york_area','area_elem')

    end %exist
elseif imode==2

    if exist('/Users/ncai/Documents/york_marsh/Grid_v24/hgrid_area_SH.mat','file')
        load('/Users/ncai/Documents/york_marsh/Grid_v24/hgrid_area_SH.mat')
        tar_area=SH_area;
    else

        gridname='/Users/ncai/Documents/york_marsh/Grid_v24/hgrid.bath1_full';
        %read *gr3 or *ll
        fid=fopen(gridname,'r');
        char=fgetl(fid);
        tmp1=str2num(fgetl(fid));
        fclose(fid);

        ne=fix(tmp1(1));
        np=fix(tmp1(2));

        fid=fopen(gridname);
        c1=textscan(fid,'%d%f%f%f',np,'headerLines',2);
        fclose(fid);
        fid=fopen(gridname);
        c2=textscan(fid,'%d%d%d%d%d%d',ne,'headerLines',2+np);
        fclose(fid);

        x=c1{2}(:);
        y=c1{3}(:);
        Cd=c1{4}(:); Cd=Cd';%for TidalEnergy calc
        i34=c2{2}(:);

        nm(1:ne,1:4)=nan;
        for i=1:ne
          for j=1:i34(i)
            nm(i,j)=fix(c2{j+2}(i));
          end %for j
          %calc elem area
          area_elem(i)=N_areacalc(x(nm(i,1:i34(i))),y(nm(i,1:i34(i))));
        end %for i
        SH_area=area_elem(sid);
        tar_area=area_elem(sid);

        save('/Users/ncai/Documents/york_marsh/Grid_v24/hgrid_area_SH.mat','ne','np','SH_area')

    end %exist

end %imode


%------------load model results------------
if exist([path_store,fname,'.mat'],'file')
    load([path_store,fname,'.mat'])
else
    
    for vv=1:length(varname)
        for pp=1:length(run)
            path=[path_org,run{pp},'/'];

            %model results
        
            %combine var? from this run
            for ii=1:5
                load([path,run{pp},'_',varname{vv},'_Zlayer_int_',num2str(ii),'.mat'])
                if ii==1
                    var=eval(['var',num2str(ii)]);
                else
                    var=[var;eval(['var',num2str(ii)])];
                end
                clear var1 var2 var3 var4 var5
            end %ii::5

            %combine var from all runs to var_all
            if pp==1
                var_all=var;
                T_all=T;
                var0=var_all;
                T0=T_all;
                tadd=T_all(end);
                clear var
            else
                T=T+tadd;
                var_all=cat(1,var0,var);
                T_all=cat(1,T0,T);
                var0=var_all;
                T0=T_all;
                tadd=T_all(end);
                clear var
            end

        end %pp::run        
    
        ttmarsh(:,:,vv)=var_all;
        clear var_all var0
        
    end %vv::varname

    %pick SH areas only to store
    SHmarsh=squeeze(ttmarsh(:,sid,:));

    %save
    save([path_store,fname,'.mat'],'SHmarsh','T_all');
end %exist


%------------analysis------------
%take TSeries
for r1=1:length(varname)
    var=squeeze(SHmarsh(:,:,r1));
    var(var<-98)=nan;
    %pick elems with marsh
    mvar=mean(var,1,'omitnan');    
    vid=find(mvar>0);
    
    %raw TSeries of spatially-averaged 
    rvar(:,r1)=(var(:,vid)*(tar_area(vid)'))/sum(tar_area(vid)); 
    if isbio==0
        if r1==length(varname)
            nd=2;int=2;
            [T_ppveg,ppveg]=Q_ave(T_all,rvar(:,r1),nd,int);
        else
            nd=20;int=20;
            [T_veg,veg(:,r1)]=Q_ave(T_all,rvar(:,r1),nd,int);
        end
    elseif isbio==1
        if r1==3
            nd=2;int=2;
            [T_ppveg,ppveg]=Q_ave(T_all,rvar(:,r1),nd,int);
        elseif r1==2
            nd=20;int=20;
            rtmp=sum(rvar(:,1:r1),2);
            [T_veg,veg(:,1)]=Q_ave(T_all,rtmp,nd,int);
        end        
        
    end %isbio
 
end %r1::varname

marsh_biomass_SH=rtmp;
marsh_pp_SH=rvar(:,3);
save([path_store,outname,'_v',num2str(pver),'.mat'],'marsh_pp_SH','marsh_biomass_SH');

figure('Position',fsize)
if isbio==0
    subplot(3,1,1)
    plot(T_veg,smooth(veg(:,1)),'LineWidth',2.5)
    % plot(T_veg,veg(:,1),'LineWidth',2.5)
    yrange=[min(veg(:,1))*0.9 max(veg(:,1))*1.1];
    ylim(yrange)
    xlim([time_left-time_ref time_right-time_ref])
    set(gca,'XTick',[],'XTickLabel',[],'FontSize',20)
    title('Above-ground biomass (g C m^-^2)')
    set(gca,'fontsize',nfontsize);

    subplot(3,1,2)
    plot(T_veg,smooth(veg(:,2)),'LineWidth',2.5)
    yrange=[min(veg(:,2))*0.9 max(veg(:,2))*1.1];
    ylim(yrange)
    xlim([time_left-time_ref time_right-time_ref])
    set(gca,'XTick',[],'XTickLabel',[],'FontSize',20)
    title('Below-ground biomass (g C m^-^2)')
    set(gca,'fontsize',nfontsize);

    subplot(3,1,3)
    time=T_ppveg+time_ref;
    plot(time,ppveg,'LineWidth',1.5)
    yrange=[min(ppveg)*0.8 max(ppveg)*1.1];
    ylim(yrange)
    xlim([time_left time_right])
    datetick('x','yyyy','keeplimits') %,'keepticks')      
    xlabel('Time (year)')
    title('Net productivity (g C m^-^2 day^-^1)')
    set(gca,'fontsize',nfontsize);

elseif isbio==1
    subplot(2,1,1)
    plot(T_veg,smooth(veg(:,1)),'LineWidth',2.5)
    % plot(T_veg,veg(:,1),'LineWidth',2.5)
    yrange=[min(veg(:,1))*0.9 max(veg(:,1))*1.1];
    ylim(yrange)
    xlim([time_left-time_ref time_right-time_ref])
    set(gca,'XTick',[],'XTickLabel',[],'FontSize',20)
    title('Marsh biomass (g C m^-^2)')
    set(gca,'fontsize',nfontsize);

    subplot(2,1,2)
    time=T_ppveg+time_ref;
    plot(time,ppveg,'LineWidth',1.5)
    yrange=[min(ppveg)*0.8 max(ppveg)*1.1];
    ylim(yrange)
    xlim([time_left time_right])
    datetick('x','yyyy','keeplimits') %,'keepticks')      
    xlabel('Time (year)')
    title('Net productivity (g C m^-^2 day^-^1)')
    set(gca,'fontsize',nfontsize);
    
%     %additional calc
%     rtmp=2*ppveg;
%     ppveg_yr=sum(rtmp)/(365*4);
    
    

end %isbio

if isave==1
    set(gcf,'PaperPositionMode','auto') 
    print('-dpng',[path_store,outname,'_v',num2str(pver),'.png'],'-r300')    
end





