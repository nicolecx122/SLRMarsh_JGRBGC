clear
close all
clc

isave=0;
imode=1; %1: base vs. slr 1.5m; 2: base vs. no marsh; 3: no-recycle vs. slr 1.5m; 4: both
pver=1; %version id
isimk=1;
run_base='tun44h';

if imode==1
    fname=[run_base,'_flux_slr'];
elseif imode==2
    fname=[run_base,'_flux_nomarsh'];
end %imode

loc_str={'Gloucester Point','Clay Bank','West Point','Pamunkey'};
loc_sp={'GP','CB','WP','PK'};
sid=3;
imk={'a','b','c','d','e','f','g','h','i','j'};
formatSpec1 = '%.1f';

if imode==1
    run={[run_base],[run_base,'_slr1_5m_macc']}; 
    leg_str={'Base','SLR = 1.5 m'};
    outname=[run_base,'_flux_slr'];
elseif imode==2
    run={[run_base],[run_base,'_0']}; 
    leg_str={'Base','NV0 (no marsh)'};
    outname=[run_base,'_flux_nomarsh'];    
elseif imode==3
    run={[run_base],[run_base,'_slr1_5m_macc1_5m'],[run_base,'0'],[run_base,'0_slr1_5m_macc1_5m']}; 
    leg_str={'Base','SLR = 1.5 m','Base, no recyclye','SLR = 1.5 m, no recyclye'};
    outname=[run_base,'_flux_norecycle_slr'];    
elseif imode==4
    run={[run_base],[run_base,'_nomarsh'],[run_base,'_slr1_5m_macc1_5m']}; 
    leg_str={'Base','No marsh','SLR = 1.5 m'};
    outname=[run_base,'_flux_both'];        
end %imode
outname=[outname,'_',loc_sp{sid},'_v',num2str(pver)];

path_org='/Users/ncai/OneDrive/Projects/york_marsh/results/';
path_store='/Users/ncai/OneDrive/Projects/york_marsh/results/WQ_york/';

%plot setup
fsize1=[1,1,650,800];
fsize2=[1,1,1300,800];
nfontsize=18;
xrange=[0 365];

%data parameters
varname={'flow','TSflux','Nflux','Pflux','Oflux','Cflux','PBflux','ONflux','OPflux'};
month={'Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'};
time=0:(150/86400):(365); time=time';
time_r=1:12;
CChl=[0.05 0.059 0.059];
% para_pk=[6 3 4 ];%[7 6 3 4 5]; %
% title_str={'DOC','DIN','PO_4^3^-'};
% mat_pk=[2 3 4];
para_pk=[ 6 3 4];%[7 6 3 4 5]; %
title_str={'DOC','DIN','PO_4^3^-'};
mat_pk=[ 2 3 4];
npara=length(para_pk);

%---------analyze---------
for pp=1:length(run)    
    for r1=[1 para_pk] %chla, carbon, nitrogon, phsphorus
        filename=[run{pp},'_',varname{r1},'.mat'];
        load([path_org,run{pp},'/',filename])     
    end %r1::varname
    
    %--flow--
    for r2=1:nface
        flow_s(:,:,pp)=squeeze(flow(:,1,:));
    end %r2::nface
    %monthly-averaged fluxes
    nd=30;int=30;
    for r2=1:nface
        [time_m,flow_sm(:,r2,pp)]=Q_ave(time,flow_s(:,r2,pp),nd,int);
    end %r2::nface
    
    %--PB--
    if ismember(7,para_pk)
        %convert PB to Chl
        for r2=1:nface
            PBflux(:,1:2:end,r2)=PBflux(:,1:2:end,r2)./CChl;
            PBflux(:,2:2:end,r2)=PBflux(:,2:2:end,r2)./CChl;
        end
        %150s fluxes
        PBflux_p(:,:,pp)=sum(PBflux(:,1:2:end,:),2);
        PBflux_n(:,:,pp)=sum(PBflux(:,2:2:end,:),2);
        %monthly-averaged fluxes
        nd=30;int=30;
        for r2=1:nface
            [time_m,PBflux_psm(:,r2,pp)]=Q_ave(time,PBflux_p(:,r2,pp),nd,int);
            [~,PBflux_nsm(:,r2,pp)]=Q_ave(time,PBflux_n(:,r2,pp),nd,int);
        end %r2::nface
        flux_tsm(:,:,pp,1)=PBflux_nsm(:,:,pp)+PBflux_psm(:,:,pp); %net flux
    end
    
    %--carbon--
    if ismember(6,para_pk)
        %150s fluxes
        Cflux_p(:,:,pp)=sum(Cflux(:,5:2:end,:),2);
        Cflux_n(:,:,pp)=sum(Cflux(:,6:2:end,:),2);
        %monthly-averaged fluxes
        nd=30;int=30;
        for r2=1:nface
            [time_m,Cflux_psm(:,r2,pp)]=Q_ave(time,Cflux_p(:,r2,pp),nd,int);
            [~,Cflux_nsm(:,r2,pp)]=Q_ave(time,Cflux_n(:,r2,pp),nd,int);
        end %r2::nface
        flux_tsm(:,:,pp,2)=Cflux_nsm(:,:,pp)+Cflux_psm(:,:,pp); %net flux
    end
    
    %--NH4, NO23--
    if ismember(3,para_pk)
        %150s fluxes
        Nflux_p(:,:,pp)=sum(Nflux(:,1:2:end,:),2);
        NH4flux_p(:,:,pp)=sum(Nflux(:,1,:),2);
        NO3flux_p(:,:,pp)=sum(Nflux(:,3,:),2);
        Nflux_n(:,:,pp)=sum(Nflux(:,2:2:end,:),2);
        NH4flux_n(:,:,pp)=sum(Nflux(:,2,:),2);
        NO3flux_n(:,:,pp)=sum(Nflux(:,4,:),2);    
        %monthly-averaged fluxes
        nd=30;int=30;
        for r2=1:nface
            [time_m,Nflux_psm(:,r2,pp)]=Q_ave(time,Nflux_p(:,r2,pp),nd,int);
            [~,Nflux_nsm(:,r2,pp)]=Q_ave(time,Nflux_n(:,r2,pp),nd,int);
            [~,NH4flux_psm(:,r2,pp)]=Q_ave(time,NH4flux_p(:,r2,pp),nd,int);
            [~,NH4flux_nsm(:,r2,pp)]=Q_ave(time,NH4flux_n(:,r2,pp),nd,int);        
            [~,NO3flux_psm(:,r2,pp)]=Q_ave(time,NO3flux_p(:,r2,pp),nd,int);
            [~,NO3flux_nsm(:,r2,pp)]=Q_ave(time,NO3flux_n(:,r2,pp),nd,int);       
        end %r2::nface
        flux_tsm(:,:,pp,3)=Nflux_nsm(:,:,pp)+Nflux_psm(:,:,pp); %net flux    

        NH4flux(:,:,pp)=NH4flux_nsm(:,:,pp)+NH4flux_psm(:,:,pp); 
        NO3flux(:,:,pp)=NO3flux_nsm(:,:,pp)+NO3flux_psm(:,:,pp); 
    end
    
    %--PO4--
    if ismember(4,para_pk)
        %150s fluxes
        Pflux_p(:,:,pp)=sum(Pflux(:,1:2:end,:),2);
        Pflux_n(:,:,pp)=sum(Pflux(:,2:2:end,:),2);
        %monthly-averaged fluxes
        nd=30;int=30;
        for r2=1:nface
            [time_m,Pflux_psm(:,r2,pp)]=Q_ave(time,Pflux_p(:,r2,pp),nd,int);
            [~,Pflux_nsm(:,r2,pp)]=Q_ave(time,Pflux_n(:,r2,pp),nd,int);
        end %r2::nface
        flux_tsm(:,:,pp,4)=Pflux_nsm(:,:,pp)+Pflux_psm(:,:,pp); %net flux       
    end
    
    %--DO--
    if ismember(5,para_pk)
        %150s fluxes
        Oflux_p(:,:,pp)=sum(Oflux(:,3:2:end,:),2);
        Oflux_n(:,:,pp)=sum(Oflux(:,4:2:end,:),2);
        %monthly-averaged fluxes
        nd=30;int=30;
        for r2=1:nface
            [time_m,Oflux_psm(:,r2,pp)]=Q_ave(time,Oflux_p(:,r2,pp),nd,int);
            [~,Oflux_nsm(:,r2,pp)]=Q_ave(time,Oflux_n(:,r2,pp),nd,int);
        end %r2::nface
        flux_tsm(:,:,pp,5)=Oflux_nsm(:,:,pp)+Oflux_psm(:,:,pp); %net flux
    end

end %pp::run

save([path_store,fname,'.mat'],'flux_tsm');

if ismember(3,para_pk)
    %additional calc
    SHNH4flux=squeeze(NH4flux(:,end,:));
    SHNO3flux=squeeze(NO3flux(:,end,:));
    TNSH=SHNH4flux+SHNO3flux;
    ratNH4SH=SHNH4flux./TNSH;
end %ismember

%--fluxes along York marsh--
%fluxes at West Point
figure('Position',fsize1)
nyork=11:(-1):3;
nyork_sec={'Horseshoe','Broad Creek','Cohoke','Cousaic','Sweet Hall','Hill','Lee','Eltham','West Point'};
mflux_tsm=mean(flux_tsm(:,:,:,:),1);
mflux_tsm=squeeze(mflux_tsm(1,:,:,:));
for r1=1:npara %CNP
    subplot(npara,1,r1)
    tvar=squeeze(mflux_tsm(nyork,:,mat_pk(r1)));
    diff=100*(tvar(:,2)-tvar(:,1))./tvar(:,1);
    bar(1:length(nyork),tvar)
    tmin=min(min(min(tvar)));
    fmin=min([0 1.3*tmin]);
    yrange=[fmin 1.2*max(max(max(tvar)))];
    ylim(yrange)

    box on
    
    if r1==npara
        set(gca,'XTick',1:length(nyork),'XTickLabel',nyork_sec)    
        set(gca,'XTickLabelRotation',25)
    else
        set(gca,'XTick',[],'XTickLabel',[])
    end    
    
    if r1==3
        legend(leg_str,'Location','northwest')
    end      
    
    vartitle=['Net ',title_str{r1},' fluxes (g s^-^1)'];
    if isimk==1
        title(['(',imk{r1},') ',vartitle])
    else
        title(vartitle)
    end           
    set(gca,'fontsize',nfontsize);

    for r2=1:length(diff)
        str1{r2}=[num2str(diff(r2),formatSpec1),'%'];
    end
    xloc=1:length(nyork); 
    yloc=max(tvar,[],2);     
    
    if imode==2
        if strcmp(title_str{r1},'DIN')
            set(gca,'YTick',0:5:90)
            ylim([0 20])

        end
        if strcmp(title_str{r1},'PO_4^3^-')
            set(gca,'YTick',-2:1:90)
            ylim([0 3])

        end
        if strcmp(title_str{r1},'DOC')
            set(gca,'YTick',0:100:300)
            ylim([0 300])

        end
    end %imode
    
    
    if imode==1
        if strcmp(title_str{r1},'DIN')
            set(gca,'YTick',0:5:90)
            ylim([0 20])

        end
        if strcmp(title_str{r1},'PO_4^3^-')
            set(gca,'YTick',-2:1:90)
            ylim([0 4])

        end
        if strcmp(title_str{r1},'DOC')
            set(gca,'YTick',0:100:800)
            ylim([0 400])

        end
    end %imode    
  
    
%     text(xloc,yloc,str1,'FontSize',15)    
    text(xloc,yloc,num2str(diff,'%.1f%%'),...
    'HorizontalAlignment','center',...
    'VerticalAlignment','bottom',...
    'FontSize',15) 

end %r1::CNP

%save
if isave==1
    figname=[outname,'_alongmarsh'];
    set(gcf,'PaperPositionMode','auto') 
    print('-dpng',[path_store,figname,'.png'],'-r300')        
end




















