clear
close all
clc

isave=1;
run_base='tun44h';
imode=1; %1: base vs. slr 1.5m; 2: base vs. no marsh; 3: base vs. no marsh vs. high marsh settling; 4: sensitivities; 5: base with high marsh settling vs. no marsh; 5: test
pver=2; %version id
imk={'a','b','c','d','e','f','g','h','i','j'};

%parameters for plot
isingleplot=0;
xrange=[0 120];
fsize=[1,1,900,800];
nfontsize=20;

if imode==1
    run={[run_base],[run_base,'_slr1_5m_macc']}; 
    leg_str={'Base','SLR = 1.5 m'};
    outname=[run_base,'_trans_slr'];
    fname=[run_base,'_WQ_slr']; %to store *.mat
elseif imode==2
    run={[run_base],[run_base,'_0']}; 
    leg_str={'Base','NV0'};
    outname=[run_base,'_trans_nomarsh'];
    fname=[run_base,'_WQ_nomarsh']; %to store *.mat
elseif imode==3
    run={[run_base],[run_base,'_0'],[run_base,'_set']}; 
    leg_str={'Base','NV0','Set'};
    outname=[run_base,'_trans_set'];
    fname=[run_base,'_WQ_set']; %to store *.mat
elseif imode==4
    run={[run_base],[run_base,'_1'],[run_base,'_2'],[run_base,'_3'],[run_base,'_4'],[run_base,'_5'],[run_base,'_6']}; 
    leg_str={'Base','growth/metabolism rates1','growth/metabolism rates2','optimal temperature1','optimal temperature2','carbon to nutrient ratio1','carbon to nutrient ratio2'};
    outname=[run_base,'_trans_sensitivitytests'];    
    fname=[run_base,'_WQ_sensitivitytests']; %to store *.mat
elseif imode==5
    run={[run_base,'_set'],[run_base,'_set0']}; 
    leg_str={'Base_set','NV0_set'};
    outname=[run_base,'_trans_baseset'];
    fname=[run_base,'_WQ_baseset']; %to store *.mat
end %imode

outname=[outname,'_v',num2str(pver)];
fname=[fname,'_v',num2str(pver)];
path_org='/Users/ncai/Documents/york_marsh/results/';
path_store='/Users/ncai/Documents/york_marsh/results/WQ_york/';
stack=[1 20];


var_name={'Chl','RPOC','LPOC','DOC',...
    'RPON','LPON','DON','NH4','NO3',...
    'RPOP','LPOP','DOP','PO4','DO'};
var_unit={'\mug L^-^1'};
for i=[6:17 21]
    tmp='g m^-^3';
    var_unit=[var_unit; tmp];
end
var_pk={'ICM_Chl'};
for i=[6:17 21]
    tmp=['ICM_',num2str(i)];
    var_pk=[var_pk; tmp];
end

par_name={'Chl','DOC','TON','NH4','NO3','TOP','PO4','DO','DIN','TN','TP','PO4d'};
par_print={'Chl','DOC','TON','NH_4^+','NO_3^-','TOP','PIP','DO','DIN','TN','TP','PO_4^3^-'};
par_unit={'\mug L^-^1','g C m^-^3','g N m^-^3','g N m^-^3','g N m^-^3','g P m^-^3','g P m^-^3','g O_2 m^-^3','g N m^-^3','g N m^-^3','g P m^-^3','g P m^-^3'};
par_grp=[1 1;...
    4 4;...
    5 7;...
    8 8;...
    9 9;...
    10 12;...
    13 13;...
    14 14;...
    8 9;...
    5 9;...
    10 13;...
    13 13];


%------------calculate distance------------
if exist('/Users/ncai/Documents/york_marsh/Grid_v24/BPfiles/york_transect.mat','file')
    load('/Users/ncai/Documents/york_marsh/Grid_v24/BPfiles/york_transect.mat')
else
    bp=load('/Users/ncai/Documents/york_marsh/Grid_v24/BPfiles/york_transect.bp1');
    npt=length(bp(:,1)); 
    
    x1=bp(1:(npt-1),2); y1=bp(1:(npt-1),3);
    x2=bp(2:npt,2); y2=bp(2:npt,3);
    dx2=(x1-x2).^2; dy2=(y1-y2).^2;
    bp_betw=sqrt(dx2+dy2); %distance between each two neibouring bps
    
    bp_dist(1)=0; %distance to the first bp
    for r1=1:(npt-1)
        bp_dist(1+r1,1)=sum(bp_betw(1:r1))/1000; %unit: km        
    end %r1=1:(npt-1)
    save('/Users/ncai/Documents/york_marsh/Grid_v23/BPfiles/york_transect.mat','bp_betw','bp_dist')
end %exist

%------------load results------------
if exist([path_store,fname,'.mat'],'file')
    load([path_store,fname,'.mat'])
else
    for r2=1:length(var_name)
        for r1=1:length(run)
            path=[path_org,run{r1},'/'];
            rtmp=load([path,num2str(stack(1)),'_',num2str(stack(2)),'_',var_pk{r2},'.york.trans.out']);
            var(:,:,r1,r2)=rtmp(:,2:end);
        end %r1::run      
    end %r2::var_name
    save([path_store,fname,'.mat'],'var');
end %exist
%annual average
mvar=mean(var,1);

%group var to par
for r2=1:length(par_name)
    rtmp=squeeze(mvar(1,:,:,par_grp(r2,1):par_grp(r2,2)));
    if strcmp(par_name{r2},'PO4d')
        rtmp1=sum(rtmp,3);    
        rtmp2=squeeze(mvar(1,:,:,2:3));
        rtmp3=4*sum(rtmp2,3);    %TSS
        rtmp4=rtmp1./(1+0.02*rtmp3);
        par(:,:,r2)=rtmp4;
    else
        par(:,:,r2)=sum(rtmp,3);    
    end
end %r2::par_name



%%
%------------plot------------
if isingleplot==1
    for r2=2:length(var_name)
        figure('Position',[1,1,1200,550]);
        para=squeeze(mvar(1,:,:,r2));

        plot(bp_dist,para,'LineWidth',4)    

        %--edit figure--
        legend(leg_str,'Location','northwest')
        xlabel('Distance from mouth (km)')
        ylabel([var_name{r2} ' (',var_unit{r2},')'])
        xlim(xrange)
        set(gca,'fontsize',20);

        if isave==1
%             saveas(gcf,[path_store,outname,'_',var_name{r2},'.fig'])
            set(gcf,'PaperPositionMode','auto') 
            print('-dpng',[path_store,outname,'_',var_name{r2},'.png'],'-r300')    
        end

    end %r2::var_name
end %isingleplot

%%
%------------plot------------
% par_pk=[1 4 5 7;8 2 3 6];

if imode==4
    par_pk=[1 8 2 7 4 5 ];
    nfig=(length(run)-1)/2;
    for r3=1:nfig
        figure('Position',fsize);
        rpk=[1 r3*2 r3*2+1];
        for t2=1:length(par_pk(:))
            subplot(3,2,t2)
            r2=par_pk(t2);
            para=squeeze(par(:,:,r2));
            for r4=1:length(rpk)
                plot(bp_dist,smooth(para(:,rpk(r4))),'LineWidth',3); hold on;
            end

            %--edit figure--
            %xrange
            xlim(xrange)

            %yrange
            if strcmp(par_name{r2},'TOC') %TOC
                yrange=[min(min(para))*0.9 max(max(para))*1.4];
            elseif strcmp(par_name{r2},'DO') %DO
                yrange=[min(min(para))*0.98 max(max(para))*1.25];
            elseif strcmp(par_name{r2},'PO4')||strcmp(par_name{r2},'NO3')||strcmp(par_name{r2},'NO4')
                yrange=[0 max(max(para))*1.25];
            else
                yrange=[min(min(para))*0.9 max(max(para))*1.1];
            end
            ylim(yrange)       
            if strcmp(par_name{r2},'Chl')
                set(gca,'YTick',[ceil(yrange(1)):2:round(yrange(2))])
            end
            if strcmp(par_name{r2},'DOC')
                set(gca,'YTick',[ceil(yrange(1)):10:round(yrange(2))])
            end
            if strcmp(par_name{r2},'NO3')
                set(gca,'YTick',[0.0:0.1:0.4])
            end        
            if strcmp(par_name{r2},'PO4')
                set(gca,'YTick',[0.0:0.02:0.2])
            end  
            if strcmp(par_name{r2},'DO')
                set(gca,'YTick',[0:2:16])
            end  
            if strcmp(par_name{r2},'NH4')
                set(gca,'YTick',[0:0.01:0.5])
            end 

            %add lines
            y=yrange; x=[18 18; 62 62; 81 81];
            plot(x,y,':','LineWidth',0.75,'Color',[0.45 0.45 0.45])

            %legend + lable + title
            if strcmp(par_name{r2},'NO3')
                legend(leg_str(rpk),'Location','northwest')
            end

            if t2>4&&r3==1
                xlabel('Distance from mouth (km)')
                set(gca,'XTick',[0:20:120])
            else
                set(gca,'XTick',[],'XTickLabel',[])
            end
            title(['(',imk{t2},') ',par_print{r2} ' (',par_unit{r2},')'])
            set(gca,'fontsize',nfontsize);

        end %r2::par_name

        if isave==1
    %         saveas(gcf,[path_store,outname,'_',num2str(r3),'.fig'])
            set(gcf,'PaperPositionMode','auto') 
            print('-dpng',[path_store,outname,'_',num2str(r3),'.png'],'-r300')    
        end

    end %r3::figure
    
elseif imode==2 %no marsh
    par_pk=[1 8 2 7 4 5];% 10 11];
    for r3=1%:2
        figure('Position',fsize);
        for t2=1:length(par_pk(1,:))
            subplot(3,2,t2)
            r2=par_pk(r3,t2);
            para=squeeze(par(:,:,r2));
            par_store(:,:,t2)=para;
            for r4=1:length(para(1,:))
                plot(bp_dist,smooth(para(:,r4)),'LineWidth',3); hold on;
            end

            %--edit figure--
            %xrange
            xlim(xrange)

            %yrange
            if strcmp(par_name{r2},'TOC') %TOC
                yrange=[min(min(para))*0.9 max(max(para))*1.4];
            elseif strcmp(par_name{r2},'DO') %DO
                yrange=[min(min(para))*0.98 max(max(para))*1.25];
            elseif strcmp(par_name{r2},'PO4')||strcmp(par_name{r2},'NO3')||strcmp(par_name{r2},'NO4')
                yrange=[0 max(max(para))*1.25];
            else
                yrange=[min(min(para))*0.9 max(max(para))*1.1];
            end
            ylim(yrange)       
            if strcmp(par_name{r2},'Chl')
%                 set(gca,'YTick',[ceil(yrange(1)):2:round(yrange(2))])
                set(gca,'YTick',[1:2:13])
                ylim([3 12])
            end
            if strcmp(par_name{r2},'DOC')
%                 set(gca,'YTick',[ceil(yrange(1)):2:round(yrange(2))])
                set(gca,'YTick',[1:2:7])
                ylim([1 7])
            end
            if strcmp(par_name{r2},'NO3')
                set(gca,'YTick',[0.0:0.1:0.3])
                ylim([0 0.3])
            end        
            if strcmp(par_name{r2},'PO4')
                set(gca,'YTick',[0.0:0.02:0.2])
                ylim([0 0.06])
            end  
            if strcmp(par_name{r2},'DO')
                set(gca,'YTick',[0:2:16])
                ylim([6 12])
            end  
            if strcmp(par_name{r2},'NH4')
                set(gca,'YTick',[0:0.01:0.5])
                ylim([0.01 0.05])
            end 

            %add lines
            y=[0 100]; x=[18 18; 62 62; 81 81];
            plot(x,y,':','LineWidth',0.75,'Color',[0.45 0.45 0.45])

            %legend + lable + title
            if strcmp(par_name{r2},'Chl')
                legend(leg_str,'Location','northeast')
            end

            if t2>4&&r3==1
                xlabel('Distance from mouth (km)')
                set(gca,'XTick',[0:20:120])
            else
                set(gca,'XTick',[],'XTickLabel',[])
            end
            title(['(',imk{t2+(r3-1)*length(par_pk(1,:))},') ',par_print{r2} ' (',par_unit{r2},')'])
            set(gca,'fontsize',nfontsize);

        end %r2::par_name

        if isave==1
    %         saveas(gcf,[path_store,outname,'_',num2str(r3),'.fig'])
            set(gcf,'PaperPositionMode','auto') 
            print('-dpng',[path_store,outname,'_',num2str(r3),'.png'],'-r300')                
        end
%         save([path_store,outname,'_',num2str(r3),'.mat'],'par_store');
    end %r3::figure
    
elseif imode==1 %SLR
    par_pk=[8 2  4 5 7 9 ];%[1 8 2 7 9 ]; %

    for r3=1%:2
        figure('Position',fsize);
        for t2=1:length(par_pk(1,:))
            subplot(3,2,t2)
            r2=par_pk(r3,t2);
            para=squeeze(par(:,:,r2));
            for r4=1:length(para(1,:))
                plot(bp_dist,smooth(para(:,r4)),'LineWidth',3); hold on;
            end

            %--edit figure--
            %xrange
            xlim(xrange)

            %yrange
            if strcmp(par_name{r2},'TOC') %TOC
                yrange=[min(min(para))*0.9 max(max(para))*1.4];
            elseif strcmp(par_name{r2},'DO') %DO
                yrange=[min(min(para))*0.98 max(max(para))*1.25];
            elseif strcmp(par_name{r2},'PO4')||strcmp(par_name{r2},'NO3')||strcmp(par_name{r2},'NO4')
                yrange=[0 max(max(para))*1.25];
            else
                yrange=[min(min(para))*0.9 max(max(para))*1.1];
            end
            ylim(yrange)       
            if strcmp(par_name{r2},'Chl')
%                 set(gca,'YTick',[ceil(yrange(1)):2:round(yrange(2))])
                set(gca,'YTick',[1:2:13])
                ylim([5 13])
            end
            if strcmp(par_name{r2},'DOC')
%                 set(gca,'YTick',[ceil(yrange(1)):2:round(yrange(2))])
                set(gca,'YTick',[2:4:10])
                ylim([2 10])
            end
            if strcmp(par_name{r2},'NO3')
                set(gca,'YTick',[0.0:0.1:0.3])
                ylim([0 0.2])
            end        
            if strcmp(par_name{r2},'PO4')
                set(gca,'YTick',[0.0:0.05:0.2])
                ylim([0 0.1])
            end  
            if strcmp(par_name{r2},'DO')
                set(gca,'YTick',[6:2.5:11])
                ylim([6 11])
            end  
            if strcmp(par_name{r2},'NH4')
                set(gca,'YTick',[0:0.01:0.5])
                ylim([0.01 0.04])
            end 
            if strcmp(par_name{r2},'DIN')
                set(gca,'YTick',[0:0.1:0.5])
                ylim([0 0.25])
            end             

            %add lines
            y=[0 100]; x=[18 18; 62 62; 81 81];
            plot(x,y,':','LineWidth',0.75,'Color',[0.45 0.45 0.45])

            %legend + lable + title
            if strcmp(par_name{r2},'DOC')
                legend(leg_str,'Location','northwest')
            end

            if t2>4&&r3==1
                xlabel('Distance from mouth (km)')
                set(gca,'XTick',[0:20:120])
            else
                set(gca,'XTick',[],'XTickLabel',[])
            end
            title(['(',imk{t2+(r3-1)*length(par_pk(1,:))},') ',par_print{r2} ' (',par_unit{r2},')'])
            set(gca,'fontsize',nfontsize);
            
            %additional calc
            if strcmp(par_name{r2},'Chl')
                CHL=para;       
                diffCHL=CHL(:,2)-CHL(:,1);
                ratCHL=diffCHL./CHL(:,1);                
            end
            if strcmp(par_name{r2},'DOC')
                DOC=para;       
                diffDOC=DOC(:,2)-DOC(:,1);
                ratDOC=diffDOC./DOC(:,1);                
            end
            if strcmp(par_name{r2},'DO')
                DOO=para;       
                diffDOO=DOO(:,2)-DOO(:,1);
                ratDOO=diffDOO./DOO(:,1);                
            end        
            if strcmp(par_name{r2},'PO4')
                PO4=para;       
                diffPO4=PO4(:,2)-PO4(:,1);
                ratPO4=diffPO4./PO4(:,1);
            end
            if strcmp(par_name{r2},'NH4')
                NH4=para;
                diffNH4=NH4(:,2)-NH4(:,1);
                ratNH4=diffNH4./NH4(:,1);
            end            
            if strcmp(par_name{r2},'NO3')
                NO3=para;
                diffNO3=NO3(:,2)-NO3(:,1);
                ratNO3=diffNO3./NO3(:,1);
            end            

        end %r2::par_name

        if isave==1
    %         saveas(gcf,[path_store,outname,'_',num2str(r3),'.fig'])
            set(gcf,'PaperPositionMode','auto') 
            print('-dpng',[path_store,outname,'_',num2str(r3),'.png'],'-r300')    
        end

    end %r3::figure
    
    
elseif imode==3 %set
    par_pk=[1 8 2 7 9 12];% 10 11];
    for r3=1%:2
        figure('Position',fsize);
        for t2=1:length(par_pk(1,:))
            subplot(3,2,t2)
            r2=par_pk(r3,t2);
            para=squeeze(par(:,:,r2));
            for r4=1:length(para(1,:))
                plot(bp_dist,smooth(para(:,r4)),'LineWidth',3); hold on;
            end

            %--edit figure--
            %xrange
            xlim(xrange)

            %yrange
            if strcmp(par_name{r2},'TOC') %TOC
                yrange=[min(min(para))*0.9 max(max(para))*1.4];
            elseif strcmp(par_name{r2},'DO') %DO
                yrange=[min(min(para))*0.98 max(max(para))*1.25];
            elseif strcmp(par_name{r2},'PO4')||strcmp(par_name{r2},'NO3')||strcmp(par_name{r2},'NO4')
                yrange=[0 max(max(para))*1.25];
            else
                yrange=[min(min(para))*0.9 max(max(para))*1.1];
            end
            ylim(yrange)       
            if strcmp(par_name{r2},'Chl')
%                 set(gca,'YTick',[ceil(yrange(1)):2:round(yrange(2))])
                set(gca,'YTick',[1:2:13])
                ylim([3 12])
            end
            if strcmp(par_name{r2},'DOC')
%                 set(gca,'YTick',[ceil(yrange(1)):2:round(yrange(2))])
                set(gca,'YTick',[1:2:7])
                ylim([1 7])
            end
            if strcmp(par_name{r2},'NO3')
                set(gca,'YTick',[0.0:0.1:0.3])
                ylim([0 0.3])
            end        
            if strcmp(par_name{r2},'PO4')
                set(gca,'YTick',[0.0:0.02:0.2])
                ylim([0 0.05])
            end  
            if strcmp(par_name{r2},'DO')
                set(gca,'YTick',[0:2:16])
                ylim([6 12])
            end  
            if strcmp(par_name{r2},'NH4')
                set(gca,'YTick',[0:0.01:0.5])
                ylim([0.01 0.05])
            end 

            %add lines
            y=[0 100]; x=[18 18; 62 62; 81 81];
            plot(x,y,':','LineWidth',0.75,'Color',[0.45 0.45 0.45])

            %legend + lable + title
            if strcmp(par_name{r2},'Chl')
                legend(leg_str,'Location','northeast')
            end

            if t2>4&&r3==1
                xlabel('Distance from mouth (km)')
                set(gca,'XTick',[0:20:120])
            else
                set(gca,'XTick',[],'XTickLabel',[])
            end
            title(['(',imk{t2+(r3-1)*length(par_pk(1,:))},') ',par_print{r2} ' (',par_unit{r2},')'])
            set(gca,'fontsize',nfontsize);

        end %r2::par_name

        if isave==1
    %         saveas(gcf,[path_store,outname,'_',num2str(r3),'.fig'])
            set(gcf,'PaperPositionMode','auto') 
            print('-dpng',[path_store,outname,'_',num2str(r3),'.png'],'-r300')    
        end

    end %r3::figure    
    
elseif imode==5 %base_set
    par_pk=[1 8 2 7 9 12];% 10 11];
    for r3=1%:2
        figure('Position',fsize);
        for t2=1:length(par_pk(1,:))
            subplot(3,2,t2)
            r2=par_pk(r3,t2);
            para=squeeze(par(:,:,r2));
            for r4=1:length(para(1,:))
                plot(bp_dist,smooth(para(:,r4)),'LineWidth',3); hold on;
            end

            %--edit figure--
            %xrange
            xlim(xrange)

            %yrange
            if strcmp(par_name{r2},'TOC') %TOC
                yrange=[min(min(para))*0.9 max(max(para))*1.4];
            elseif strcmp(par_name{r2},'DO') %DO
                yrange=[min(min(para))*0.98 max(max(para))*1.25];
            elseif strcmp(par_name{r2},'PO4')||strcmp(par_name{r2},'NO3')||strcmp(par_name{r2},'NO4')
                yrange=[0 max(max(para))*1.25];
            else
                yrange=[min(min(para))*0.9 max(max(para))*1.1];
            end
            ylim(yrange)       
            if strcmp(par_name{r2},'Chl')
%                 set(gca,'YTick',[ceil(yrange(1)):2:round(yrange(2))])
                set(gca,'YTick',[1:2:13])
                ylim([3 12])
            end
            if strcmp(par_name{r2},'DOC')
%                 set(gca,'YTick',[ceil(yrange(1)):2:round(yrange(2))])
                set(gca,'YTick',[1:2:7])
                ylim([1 7])
            end
            if strcmp(par_name{r2},'NO3')
                set(gca,'YTick',[0.0:0.1:0.3])
                ylim([0 0.3])
            end        
            if strcmp(par_name{r2},'PO4')
                set(gca,'YTick',[0.0:0.02:0.2])
                ylim([0 0.05])
            end  
            if strcmp(par_name{r2},'DO')
                set(gca,'YTick',[0:2:16])
                ylim([6 12])
            end  
            if strcmp(par_name{r2},'NH4')
                set(gca,'YTick',[0:0.01:0.5])
                ylim([0.01 0.05])
            end 

            %add lines
            y=[0 100]; x=[18 18; 62 62; 81 81];
            plot(x,y,':','LineWidth',0.75,'Color',[0.45 0.45 0.45])

            %legend + lable + title
            if strcmp(par_name{r2},'Chl')
                legend(leg_str,'Location','northeast')
            end

            if t2>4&&r3==1
                xlabel('Distance from mouth (km)')
                set(gca,'XTick',[0:20:120])
            else
                set(gca,'XTick',[],'XTickLabel',[])
            end
            title(['(',imk{t2+(r3-1)*length(par_pk(1,:))},') ',par_print{r2} ' (',par_unit{r2},')'])
            set(gca,'fontsize',nfontsize);

        end %r2::par_name

        if isave==1
    %         saveas(gcf,[path_store,outname,'_',num2str(r3),'.fig'])
            set(gcf,'PaperPositionMode','auto') 
            print('-dpng',[path_store,outname,'_',num2str(r3),'.png'],'-r300')    
        end

    end %r3::figure    

end %imode

% %% additional calc
% 
% t2=5;
% r2=par_pk(r3,t2);
% para=squeeze(par(:,:,r2));
% 
% diff=para(:,2)-para(:,1);
% rat=diff./para(:,1);





