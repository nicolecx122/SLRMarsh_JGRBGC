clear
close all
clc

isave=0;
pver=1; %version id
isimk=1;
run_base='tun44h';
imk={'a','b','c','d','e','f','g','h','i','j'};
formatSpec1 = '%.1f';

outname=[run_base,'_flux_slr_DO_alongmarsh'];    

outname=[outname,'_v',num2str(pver)];
path_org='/Users/ncai/OneDrive/Projects/york_marsh/results/';
path_store='/Users/ncai/OneDrive/Projects/york_marsh/results/WQ_york/';

%plot setup
fsize1=[1,1,800,700];
nfontsize=19;

%data parameters
varname={'flow','TSflux','Nflux','Pflux','Oflux','Cflux','PBflux','ONflux','OPflux'};
month={'Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'};
time=0:(150/86400):(365); time=time';
time_r=1:12;
para_pk=5; %[7 6 3 4];%[7 6 3 4 5];
npara=length(para_pk);
tract={'Gloucester Point','Clay Bank','West Point','Eltham','Lee','Hill','Sweet Hall','Cousaic','Cohoke','Broad Creek','Horseshoe',};
trid=1;

%---------base run---------
for r1=para_pk 
    filename=[run_base,'_',varname{r1},'.mat'];
    load([path_org,run_base,'/',filename])       
end %r1::varname
% oxygen
oflux_pbas=squeeze(Oflux(:,3,:))/1000;
oflux_nbas=squeeze(Oflux(:,4,:))/1000;

nd=30;int=30;
for r3=trid %1:5
    
    [time_m, oflux_pbasm(:,r3)]=Q_ave(time,oflux_pbas(:,r3),nd,int);
    [time_m, oflux_nbasm(:,r3)]=Q_ave(time,oflux_nbas(:,r3),nd,int);
    oflux_basm(:,r3)=oflux_pbasm(:,r3)+oflux_nbasm(:,r3);        
    tmp=reshape(oflux_pbasm(:,r3),12,[]);
    oflux_pbasr(:,r3)=mean(tmp,2);
    tmp=reshape(oflux_nbasm(:,r3),12,[]);
    oflux_nbasr(:,r3)=mean(tmp,2);
    oflux_basr(:,r3)=oflux_pbasr(:,r3)+oflux_nbasr(:,r3);    
end
oflux_pbasy=mean(oflux_pbas); oflux_pbasy=oflux_pbasy';
oflux_nbasy=mean(oflux_nbas); oflux_nbasy=oflux_nbasy';
oflux_basy=oflux_pbasy+oflux_nbasy;

%---------slr run---------
run=[run_base,'_slr1_5m_macc'];
for r1=para_pk 
    filename=[run,'_',varname{r1},'.mat'];
    load([path_org,run,'/',filename])
end %r1::varname    
% oxygen
oflux_pslr=squeeze(Oflux(:,3,:))/1000;
oflux_nslr=squeeze(Oflux(:,4,:))/1000;    

%---spatial distribution figure---
oflux_pslry=mean(oflux_pslr); oflux_pslry=oflux_pslry';
oflux_nslry=mean(oflux_nslr); oflux_nslry=oflux_nslry';
oflux_slry=oflux_pslry+oflux_nslry;    
x=1:11; %cross section

figure('Position',fsize1);        
subplot(3,1,1)
% plot(x,oflux_nbasy,'-x','LineWidth',2,'MarkerSize',5)
% hold on 
% plot(x,oflux_nslry,'-o','LineWidth',2,'MarkerSize',5)
rtmp=[oflux_nbasy oflux_nslry];
% rtmp(5,1)=-oflux_pbasy(5);
% rtmp(5,2)=-oflux_pslry(5);
bar(x,rtmp(end:-1:1,:))
diff=100*(rtmp(:,2)-rtmp(:,1))./rtmp(:,1);
for r2=1:length(diff)
    str1{r2}=[num2str(diff(r2),formatSpec1),'%'];
end
xloc=x-0.4;
yloc=min(rtmp,[],2);  yloc=yloc-2.5;
text(xloc(2:end),yloc(end-1:-1:1),str1(end-1:-1:1),'FontSize',15) 
set(gca,'XTick',[],'XTickLabel',[])
%     xlabel('Cross section')
legend("Base","SLR = 1.5 m",'Location','southwest')
title('(a) Oxygen flux into the York River (kg s^-^1)','FontSize',17)       
xlim([x(1)-0.5 x(end)+0.5])   
ylim([-35 0])
set(gca,'fontsize',nfontsize);

subplot(3,1,2)
% plot(x,oflux_pbasy,'-x','LineWidth',2,'MarkerSize',5)
% hold on 
% plot(x,oflux_pslry,'-o','LineWidth',2,'MarkerSize',5)
rtmp=[oflux_pbasy oflux_pslry];
% rtmp(5,1)=-oflux_nbasy(5);
% rtmp(5,2)=-oflux_nslry(5);
bar(x,rtmp(end:-1:1,:))
diff=100*(rtmp(:,2)-rtmp(:,1))./rtmp(:,1);
for r2=1:length(diff)
    str1{r2}=[num2str(diff(r2),formatSpec1),'%'];
end
xloc=x-0.4;
yloc=max(rtmp,[],2);  yloc=yloc+2.5;
text(xloc(1:end),yloc(end:-1:1),str1(end:-1:1),'FontSize',15) 
%     legend("Base",slrn{r2})     
% set(gca,'xtick',1:5)
set(gca,'XTick',[],'XTickLabel',[])
%     xlabel('Cross section')
set(gca,'fontsize',19);
title('(b) Oxygen flux out of the York River (kg s^-^1)','FontSize',17)        
xlim([x(1)-0.5 x(end)+0.5])     
ylim([0 35])
set(gca,'fontsize',nfontsize);

subplot(3,1,3)
% plot(x,oflux_basy,'-x','LineWidth',2,'MarkerSize',5)
% hold on 
% plot(x,oflux_slry,'-o','LineWidth',2,'MarkerSize',5)
rtmp=[oflux_basy oflux_slry];
% rtmp(5,:)=-rtmp(5,:);
bar(x,rtmp(end:-1:1,:))
diff=100*(rtmp(:,2)-rtmp(:,1))./rtmp(:,1);
for r2=1:length(diff)
    str1{r2}=[num2str(diff(r2),formatSpec1),'%'];
end
xloc=x-0.4;
yloc=max(rtmp,[],2);  yloc=yloc+0.15;
text(xloc(1:end),yloc(end:-1:1),str1(end:-1:1),'FontSize',15) 
set(gca,'xtick',1:11)
set(gca,'xticklabel',tract(end:-1:1))
%     xlabel('Cross section')
set(gca,'fontsize',19);
title('(c) Net oxygen flux along the York River Estuary (kg s^-^1)','FontSize',17)      
xlim([x(1)-0.5 x(end)+0.5])   
ylim([0 2.1])
set(gca,'fontsize',nfontsize); 
set(gca,'XTickLabelRotation',25)

%additional calc
diff=(rtmp(:,2)-rtmp(:,1))./rtmp(:,1);

%save
if isave==1
    figname=[outname];
    set(gcf,'PaperPositionMode','auto') 
    print('-dpng',[path_store,figname,'.png'],'-r300')        
end

