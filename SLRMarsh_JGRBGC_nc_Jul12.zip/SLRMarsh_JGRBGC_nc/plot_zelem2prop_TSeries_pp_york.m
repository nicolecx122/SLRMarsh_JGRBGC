clear
close all
clc

isave_fig=0;
iprop=0;
run_base='tun44h';
imode=1; %1: base vs. slr 1.5m; 2: base vs. no marsh 
pver=1; %version id
imk={'a','b','c','d','e','f','g','h','i','j'};
isave_mat=1;

if imode==1
    run={[run_base],[run_base,'_slr1_5m_macc']}; 
    leg_str={'Base','SLR = 1.5 m'};
    outname=[run_base,'_pp_slr'];
    fname=[run_base,'_1_pp_slr']; %to store *.mat
    propname={[run_base,'_pp_base'],[run_base,'_pp_slr'],[run_base,'_pp_diff_slr'],[run_base,'_pp_rat_slr']}; 
elseif imode==2
    run={[run_base],[run_base,'_0']}; 
    leg_str={'Base','Marsh removal'};
    outname=[run_base,'_pp_nomarsh'];
    fname=[run_base,'_1_pp_nomarsh']; %to store *.mat
    propname={[run_base,'_pp_base'],[run_base,'_pp_nomarsh'],[run_base,'_pp_diff_nomarsh'],[run_base,'_pp_rat_nomarsh']};     
end %islr
outname=[outname,'_v',num2str(pver)];
path_org='/Users/ncai/OneDrive/Projects/york_marsh/results/';
path_store='/Users/ncai/OneDrive/Projects/york_marsh/results/WQ_york/';
path_mat='/Users/ncai/OneDrive/VIMS/Dissertation/Chap3_4/open_database/SLRMarsh_JGRBGC/';


varname={'ICM_PrmPrdt'};

%plot setup
fsize=[1,1,650,300];
nfontsize=20;
xrange=[0 365];

%------------read in mapping, calc elem area------------
%pick York
york=load('/Users/ncai/OneDrive/Projects/york_marsh/Grid_v24/BPfiles/york.prop');
sid=find(york(:,2)==1);

%read in hgrid.gr3 for elem area
if exist('/Users/ncai/OneDrive/Projects/york_marsh/Grid_v24/hgrid_area_york.mat','file')
    load('/Users/ncai/OneDrive/Projects/york_marsh/Grid_v24/hgrid_area_york.mat')
else

    gridname='/Users/ncai/OneDrive/Projects/york_marsh/Grid_v24/hgrid.bath1_full';
    %read *gr3 or *ll
    fid=fopen(gridname,'r');
    char=fgetl(fid);
    tmp1=str2num(fgetl(fid));
    fclose(fid);

    ne=fix(tmp1(1));
    np=fix(tmp1(2));

    fid=fopen(gridname);
    c1=textscan(fid,'%d%f%f%f',np,'headerLines',2);
    fclose(fid);
    fid=fopen(gridname);
    c2=textscan(fid,'%d%d%d%d%d%d',ne,'headerLines',2+np);
    fclose(fid);

    x=c1{2}(:);
    y=c1{3}(:);
    Cd=c1{4}(:); Cd=Cd';%for TidalEnergy calc
    i34=c2{2}(:);

    nm(1:ne,1:4)=nan;
    for i=1:ne
      for j=1:i34(i)
        nm(i,j)=fix(c2{j+2}(i));
      end %for j
      %calc elem area
      area_elem(i)=N_areacalc(x(nm(i,1:i34(i))),y(nm(i,1:i34(i))));
    end %for i

    york_area=area_elem(sid);

    save('/Users/ncai/OneDrive/Projects/york_marsh/Grid_v24/hgrid_area_york.mat','ne','np','york_area','area_elem')

end %exist


%------------load model results------------
if exist([path_store,fname,'.mat'],'file')
    load([path_store,fname,'.mat'])
else
    
    for vv=1:length(varname)
        for pp=1:length(run)
            path=[path_org,run{pp},'/'];
        
            %combine var? from this run
            for ii=1:5
                load([path,run{pp},'_',varname{vv},'_Zlayer_int_',num2str(ii),'.mat'])
                if ii==1
                    var=eval(['var',num2str(ii)]);
                else
                    var=[var;eval(['var',num2str(ii)])];
                end
                clear var1 var2 var3 var4 var5
            end %ii::5
            
            chlpp(:,:,vv,pp)=var;
            clear var

        end %pp::run        

    end %vv::varname

    %pick certain areas only to store
    pp_york=squeeze(chlpp(:,sid,:,:));
    pp_york(pp_york<-98)=nan;
    %save
    save([path_store,fname,'.mat'],'pp_york','T');
end %exist

%%
%------------analysis------------

%--TSeries of york-averaged pp for base and slr case--
for r1=1:length(run)
    rpp=squeeze(pp_york(:,:,r1));
    rpp(isnan(rpp))=0;
    mpp(:,r1)=(rpp*(york_area'))/sum(york_area);     
    
    nd=1;int=1;
    [T_day,mpp_day(:,r1)]=Q_ave(T,mpp(:,r1),nd,int);
    
end %pp::run

%plot
figure('Position',fsize)
plot(T_day,mpp_day,'LineWidth',2)
xlim(xrange)
xlabel('Time (day)')
title('Phytoplankton production (g C m^-^2 day^-^1)');
legend(leg_str,'Location','northwest')
set(gca,'fontsize',nfontsize);

if isave_fig==1
    set(gcf,'PaperPositionMode','auto') 
    print('-dpng',[path_store,outname,'.png'],'-r300')    
end



%--mapping of annual-averaged pp for base and slr case--
%tpp prepared from last section
ypp=mean(pp_york,1,'omitnan');
ypp=squeeze(ypp(1,:,:));

ypp_all=zeros(ne,4);
ypp_all(sid,1:2)=ypp;
ypp_all(:,3)=ypp_all(:,2)-ypp_all(:,1);
ypp_all(:,4)=100*ypp_all(:,3)./ypp_all(:,1);


if iprop==1
    for ii=1:4
        fid=fopen([path_store,propname{ii},'.prop'],'w+');
        for r1=1:ne
            fprintf(fid,'%d %10.3f \n',r1,ypp_all(r1,ii));
        end %r1::ne
        fclose(fid);
    end %ii::propfile
end %iprop

if isave_mat==1
    save([path_mat,'pp_slr.mat'],'ypp_all','T_day','mpp_day')
end





