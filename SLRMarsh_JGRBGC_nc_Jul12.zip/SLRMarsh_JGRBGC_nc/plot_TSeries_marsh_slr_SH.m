clear
close all
clc

isave=0;
isave_mat=0;
run_base='tun44h';
islr=1; %1: 
pver=2; %version id
isimk=0;
imk={'a','b','c','d','e','f','g','h','i','j'};
fsize=[1,1,600,600];
nfontsize=19;

if islr==1
    run={[run_base],[run_base,'_slr1_5m_macc']}; 
    leg_str={'Base','SLR = 1.5 m'};
    outname=[run_base,'_marsh_slr_SH'];
end %islr

outname=[outname,'_v',num2str(pver)];
path_org='/Users/ncai/OneDrive/Projects/york_marsh/results/';
stack=[1 20];
path_store='/Users/ncai/OneDrive/Projects/york_marsh/results/WQ_york/';
path_mat='/Users/ncai/OneDrive/VIMS/Dissertation/Chap3_4/open_database/SLRMarsh_JGRBGC/';


%parameters
%--growth--
fam=0.2; fplf=0.6; fpst=0.3; fprt=0.1;
%--metabolism--
bmlfr=0.03; bmstr=0.04;bmrtr=0.04;
trlf=20; trst=20; trrt=20;
ktblf=0.069; ktbst=0.069; ktbrt=0.069;


%load model results
for r1=1:length(run)
    path=[path_org,run{r1},'/'];
    tlfveg3(:,:,r1)=load([path,num2str(stack(1)),'_',num2str(stack(2)),'_ICM_tlfveg3.SH.out']);%temp
    tstveg3(:,:,r1)=load([path,num2str(stack(1)),'_',num2str(stack(2)),'_ICM_tstveg3.SH.out']);%temp
    trtveg3(:,:,r1)=load([path,num2str(stack(1)),'_',num2str(stack(2)),'_ICM_trtveg3.SH.out']);%temp

    ffveg(:,:,r1)=load([path,num2str(stack(1)),'_',num2str(stack(2)),'_ICM_ffveg.SH.out']);
    fiveg(:,:,r1)=load([path,num2str(stack(1)),'_',num2str(stack(2)),'_ICM_fiveg.SH.out']);
%     fnveg(:,:,r1)=load([path,num2str(stack(1)),'_',num2str(stack(2)),'_ICM_fnveg.SH.out']);
%     fpveg(:,:,r1)=load([path,num2str(stack(1)),'_',num2str(stack(2)),'_ICM_fpveg.SH.out']);
    fsveg(:,:,r1)=load([path,num2str(stack(1)),'_',num2str(stack(2)),'_ICM_fsveg.SH.out']);
%     plfveg(:,:,r1)=load([path,num2str(stack(1)),'_',num2str(stack(2)),'_ICM_plfveg.SH.out']);
%     pmaxveg(:,:,r1)=load([path,num2str(stack(1)),'_',num2str(stack(2)),'_ICM_pmaxveg.SH.out']);
%     temp(:,:,r1)=load([path,num2str(stack(1)),'_',num2str(stack(2)),'_air_temperature.SH.out']);
    prmprdt(:,:,r1)=load([path,num2str(stack(1)),'_',num2str(stack(2)),'_ICM_PrmPrdtveg.SH.out']);

    %model time 
    time=tlfveg3(:,1,1);

end %r1::run

%analysis and smooth
nd=10;int=3; %smoother
pkid=[3  13]; %[3 9 13]
para_str={'Net productivity','Inundation stress','Nitrogen limitation','Light limitation','Salinity stress','Phsphorus limitation','Maximun growth rate','Leaf biomass','Leaf growth rate'};
for r1=pkid
    pid=find(pkid==r1);
    %prmprdt
    tmp=squeeze(prmprdt(:,r1+1,:));
    for r2=1:length(run)
        [T_day,smDB(:,pid,r2,1)]=Q_ave(time,tmp(:,r2),nd,int);        
    end %r2::run
    
    %ffveg
    tmp=squeeze(ffveg(:,r1+1,:));
    for r2=1:length(run)
        [T_day,smDB(:,pid,r2,2)]=Q_ave(time,tmp(:,r2),nd,int);        
    end %r2::run    
    
%     %fnveg
%     tmp=squeeze(fnveg(:,r1+1,:));
%     for r2=1:length(run)
%         [T_day,smDB(:,pid,r2,3)]=Q_ave(time,tmp(:,r2),nd,int);        
%     end %r2::run    
    
    %fiveg
    tmp=squeeze(fiveg(:,r1+1,:));
    for r2=1:length(run)
        [T_day,smDB(:,pid,r2,4)]=Q_ave(time,tmp(:,r2),nd,int);        
    end %r2::run    
    
    %fsveg
    tmp=squeeze(fsveg(:,r1+1,:));
    for r2=1:length(run)
        [T_day,smDB(:,pid,r2,5)]=Q_ave(time,tmp(:,r2),nd,int);        
    end %r2::run      
    
%     %fpveg
%     tmp=squeeze(fpveg(:,r1+1,:));
%     for r2=1:length(run)
%         [T_day,smDB(:,pid,r2,6)]=Q_ave(time,tmp(:,r2),nd,int);        
%     end %r2::run    
    
%     %pmaxveg
%     tmp=squeeze(pmaxveg(:,r1+1,:));
%     for r2=1:length(run)
%         [T_day,smDB(:,pid,r2,7)]=Q_ave(time,tmp(:,r2),nd,int);        
%     end %r2::run  
    
    %tlfveg
    tmp=squeeze(tlfveg3(:,r1+1,:));
    for r2=1:length(run)
        [T_day,smDB(:,pid,r2,8)]=Q_ave(time,tmp(:,r2),nd,int);        
    end %r2::run      
    
%     %plfveg
%     tmp=squeeze(plfveg(:,r1+1,:));
%     for r2=1:length(run)
%         [T_day,smDB(:,pid,r2,9)]=Q_ave(time,tmp(:,r2),nd,int);        
%     end %r2::run          
end %pk sampling point


figure('Position',fsize)
parapk=[1 2 4 5 ];
for r1=1:length(pkid)


    for r2=parapk
        kid=find(parapk==r2);
        para=squeeze(smDB(:,r1,:,r2));
        
        %subplot location
        tid=length(pkid)*(kid-1)+r1;
        subplot(length(parapk),length(pkid),tid)
        plot(T_day,para,'LineWidth',2); 
        
        %edit figure
        if tid==4
            legend(leg_str,'Location','southwest')
        end
        
        xlim([0 365])

        if tid<=length(pkid)*(length(parapk)-1)
            set(gca,'XTick',[],'XTickLabel',[])
        else
            set(gca,'XTick',[0:100:365])
            xlabel('Time (day)')
        end
%         title(para_str{r2})
        
        if r2>2
            ylim([0 1.01])
        elseif r2==2
            ylim([0.5 1.05])

        else
            ylim([-16 16])
        end
                if r1>1
            set(gca,'YTick',[],'YTickLabel',[])
        end

        set(gca,'fontsize',nfontsize);
    end %r2::para

end %r1::sampling pts

if isave==1
    set(gcf,'PaperPositionMode','auto') 
    print('-dpng',[path_store,outname,'.png'],'-r300')    
end

if isave_mat==1
    save([path_mat,'Marsh_growth_slr.mat'],'smDB')
end



